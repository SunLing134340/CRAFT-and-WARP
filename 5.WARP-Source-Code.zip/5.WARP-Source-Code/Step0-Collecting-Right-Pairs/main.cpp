#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fstream>

using namespace std;

int InputDiff[8] = {0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0a00, 0x0000};
int OutputDiff[8] = {0x0000, 0x0000, 0x0000, 0xa000, 0x0000, 0x0000, 0x0000, 0x0000};
int KeyDiff[8] = {0x00a0, 0x0000, 0x0000, 0xa000, 0x0000, 0x0050, 0x0000, 0x0000};
int TotalEncryptionRound = 27;

int S[16]={0xc, 0xa, 0xd, 0x3, 0xe, 0xb, 0xf, 0x7, 0x8, 0x9, 0x1, 0x5, 0x0, 0x2, 0x4, 0x6};

int Pi[32] = {31, 6, 29, 14, 1, 12, 21, 8, 27, 2, 3, 0, 25, 4, 23, 10, 15, 22, 13, 30, 17, 28, 5, 24, 11, 18, 19, 16, 9, 20, 7, 26};
int InvPi[32];

void S_fun(int *in, int * out)
{
    int a=(*in);
    (*out)=S[a];
}

void WARP_Encryption(int plaintext[8], int key[8], int ciphertext[8], int * EncRound)
{
    int X[32];
    int K[32];
    for (int group = 0; group < 8; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            X[4 * group + nibble] = ((plaintext[group] >> (4 * (3 - nibble))) & (0xf));
            K[4 * group + nibble] = ((key[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    
    int RoundConstant[41][2] = {{0x0, 0x4}, {0x0, 0xc}, {0x1, 0xc}, {0x3, 0xc}, {0x7, 0xc}, {0xf, 0xc}, {0xf, 0x8}, {0xf, 0x4}, {0xe, 0x8}, {0xd, 0x4}, {0xa, 0x8}, {0x5, 0x4}, {0xa, 0xc}, {0x5, 0x8}, {0xb, 0x0}, {0x6, 0x4}, {0xc, 0xc}, {0x9, 0x8}, {0x3, 0x4}, {0x6, 0xc}, {0xd, 0xc}, {0xb, 0x8}, {0x7, 0x4}, {0xe, 0xc}, {0xd, 0x8}, {0xb, 0x4}, {0x6, 0x8}, {0xd, 0x0}, {0xa, 0x4}, {0x4, 0x8}, {0x9, 0x0}, {0x2, 0x4}, {0x4, 0xc}, {0x9, 0xc}, {0x3, 0x8}, {0x7, 0x0}, {0xe, 0x0}, {0xc, 0x4}, {0x8, 0x8}, {0x1, 0x4}, {0x2, 0xc}};
    
    for (int round = 0; round < (*EncRound); round++)
    {
        int Sout[16];
        for (int branch = 0; branch < 16; branch++)
        {
            Sout[branch] = S[X[2 * branch]];
            Sout[branch] ^= K[16 * (round%2) + branch];
        }
        int Temp[32];
        for (int branch = 0; branch < 16; branch++)
        {
            Temp[2 * branch] = X[2 * branch];
            Temp[2 * branch + 1] = X[2 * branch + 1] ^ Sout[branch];
        }
        Temp[1] ^= RoundConstant[round][0];
        Temp[3] ^= RoundConstant[round][1];
        
        if (round < 40)
        {
            for (int branch = 0; branch < 32; branch++)
            {
                X[branch] = Temp[InvPi[branch]];
            }
        }
        else
        {
            for (int branch = 0; branch < 32; branch++)
            {
                X[branch] = Temp[branch];
            }
        }
    }
    
    for (int group = 0; group < 8; group++)
    {
        ciphertext[group] = 0;
        for (int nibble = 0; nibble < 4; nibble++)
        {
            ciphertext[group] ^= (X[4 * group + nibble] << (4 * (3 - nibble)));
        }
    }
}

int main()
{
    for (int i = 0; i < 32; i++)
    {
        InvPi[Pi[i]] = i;
    }
    ofstream fout("MemoriseRightPair.out");
    
    srand(time(0));
    
    clock_t start_time, end_time;
    start_time = clock();
    
    int Key_Pair1[8] = {0x3b09, 0xfaab, 0x8d77, 0xf7f1, 0x0fa4, 0xd8f6, 0x91f7, 0x6f1e};
    int Key_Pair2[8] = {0x3ba9, 0xfaab, 0x8d77, 0x57f1, 0x0fa4, 0xd8a6, 0x91f7, 0x6f1e};
    
    unsigned int RandomSeed[2];
    unsigned int TemporaryValue;
    int Random[8];
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            Random[j] = (rand()&(0xf));
        }
        RandomSeed[i] = ((Random[0] << 28) ^ (Random[1] << 24) ^ (Random[2] << 20) ^ (Random[3] << 16) ^ (Random[4] << 12) ^ (Random[5] << 8) ^ (Random[6] << 4) ^ (Random[7]));
    }
    
    fout<<"Key_Pair1: ";
    cout<<"Key_Pair1: ";
    for (int group = 0; group < 8; group++)
    {
        fout<<"0x";
        cout<<"0x";
        for (int nibble = 0; nibble < 4; nibble++)
        {
            fout << (hex) << ((Key_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
            cout << (hex) << ((Key_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
        }
        fout<<" ";
        cout<<" ";
    }
    fout<<"\n";
    cout<<"\n";
    
    fout<<"Key_Pair2: ";
    cout<<"Key_Pair2: ";
    for (int group = 0; group < 8; group++)
    {
        fout<<"0x";
        cout<<"0x";
        for (int nibble = 0; nibble < 4; nibble++)
        {
            fout << (hex) << ((Key_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
            cout << (hex) << ((Key_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
        }
        fout<<" ";
        cout<<" ";
    }
    fout<<"\n";
    cout<<"\n";
    
    
    int Counter = 0;
    
    for (int data = 0; data < (1 << 31); data++)
    {
        int Plaintext_Pair1[8];
        int Plaintext_Pair2[8];
        int Ciphertext_Pair1[8];
        int Ciphertext_Pair2[8];
        
        for (int group = 0; group < 8; group++)
        {
            TemporaryValue = (RandomSeed[1] ^ (RandomSeed[1] << 31)^(RandomSeed[0] >> 1));
            RandomSeed[0] = RandomSeed[1];
            RandomSeed[1] = TemporaryValue;
            Plaintext_Pair1[group] = (RandomSeed[0] & (0xffff));
            Plaintext_Pair2[group] = (Plaintext_Pair1[group] ^ InputDiff[group]);
        }
        
        WARP_Encryption(Plaintext_Pair1, Key_Pair1, Ciphertext_Pair1, &TotalEncryptionRound);
        WARP_Encryption(Plaintext_Pair2, Key_Pair2, Ciphertext_Pair2, &TotalEncryptionRound);
        
        if (((Ciphertext_Pair1[0] ^ Ciphertext_Pair2[0]) == OutputDiff[0]) &&
            ((Ciphertext_Pair1[1] ^ Ciphertext_Pair2[1]) == OutputDiff[1]) &&
            ((Ciphertext_Pair1[2] ^ Ciphertext_Pair2[2]) == OutputDiff[2]) &&
            ((Ciphertext_Pair1[3] ^ Ciphertext_Pair2[3]) == OutputDiff[3]) &&
            ((Ciphertext_Pair1[4] ^ Ciphertext_Pair2[4]) == OutputDiff[4]) &&
            ((Ciphertext_Pair1[5] ^ Ciphertext_Pair2[5]) == OutputDiff[5]) &&
            ((Ciphertext_Pair1[6] ^ Ciphertext_Pair2[6]) == OutputDiff[6]) &&
            ((Ciphertext_Pair1[7] ^ Ciphertext_Pair2[7]) == OutputDiff[7]))
        {
            Counter += 1;
            fout<<"Right Pair "<<(dec)<<Counter<<"\n";
            cout<<"Right Pair "<<(dec)<<Counter<<"\n";
            fout<<"Plaintext1: ";
            cout<<"Plaintext1: ";
            for (int group = 0; group < 8; group++)
            {
                fout<<"0x";
                cout<<"0x";
                for (int nibble = 0; nibble < 4; nibble++)
                {
                    fout << (hex) << ((Plaintext_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
                    cout << (hex) << ((Plaintext_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
                }
                fout<<" ";
                cout<<" ";
            }
            fout<<"\n";
            cout<<"\n";
            fout<<"Plaintext2: ";
            cout<<"Plaintext2: ";
            for (int group = 0; group < 8; group++)
            {
                fout<<"0x";
                cout<<"0x";
                for (int nibble = 0; nibble < 4; nibble++)
                {
                    fout << (hex) << ((Plaintext_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
                    cout << (hex) << ((Plaintext_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
                }
                fout<<" ";
                cout<<" ";
            }
            fout<<"\n";
            cout<<"\n";
            fout<<"Ciphertext1: ";
            cout<<"Ciphertext1: ";
            for (int group = 0; group < 8; group++)
            {
                fout<<"0x";
                cout<<"0x";
                for (int nibble = 0; nibble < 4; nibble++)
                {
                    fout << (hex) << ((Ciphertext_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
                    cout << (hex) << ((Ciphertext_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
                }
                fout<<" ";
                cout<<" ";
            }
            fout<<"\n";
            cout<<"\n";
            fout<<"Ciphertext2: ";
            cout<<"Ciphertext2: ";
            for (int group = 0; group < 8; group++)
            {
                fout<<"0x";
                cout<<"0x";
                for (int nibble = 0; nibble < 4; nibble++)
                {
                    fout << (hex) << ((Ciphertext_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
                    cout << (hex) << ((Ciphertext_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
                }
                fout<<" ";
                cout<<" ";
            }
            fout<<"\n";
            cout<<"\n";
        }
    }
    
    cout<<"The number of right pairs: "<<(dec)<<Counter<<endl;
    end_time = clock();
    cout<<"Runtime: "<<(double)(end_time - start_time) / CLOCKS_PER_SEC<<"S"<<endl;
    fout.close();
    return 0;
}
