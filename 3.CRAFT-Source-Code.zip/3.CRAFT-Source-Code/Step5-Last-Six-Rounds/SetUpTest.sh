for((a=0;a<16;a++));do
    mkdir $a.Case-$a
    sed '6c #define KeyIndex '$a'' main.cpp > $a.Case-$a/main.cpp
    cd $a.Case-$a
    g++ -o test main.cpp -O3
    nohup ./test &
    cd ..
done;
