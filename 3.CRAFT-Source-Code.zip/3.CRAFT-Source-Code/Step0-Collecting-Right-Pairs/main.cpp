#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fstream>

#define TotalRound 32

using namespace std;

int S[16] = {0xc, 0xa, 0xd, 0x3, 0xe, 0xb, 0xf, 0x7, 0x8, 0x9, 0x1, 0x5, 0x0, 0x2, 0x4, 0x6};

void InitialiseTK(int K0[4], int K1[4], int Tweak[4], int TK[4][16])
{
    int K0_Vec[16];
    int K1_Vec[16];
    int Tweak_Vec[16];
    int QTweak_Vec[16];
    
    int Q[16] = {0xc, 0xa, 0xf, 0x5, 0xe, 0x8, 0x9, 0x2, 0xb, 0x3, 0x7, 0x4, 0x6, 0x0, 0x1, 0xd};
    
    for (int group = 0; group < 4; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            K0_Vec[4 * group + nibble] = ((K0[group] >> (4 * (3 - nibble))) & (0xf));
            K1_Vec[4 * group + nibble] = ((K1[group] >> (4 * (3 - nibble))) & (0xf));
            Tweak_Vec[4 * group + nibble] = ((Tweak[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    for (int nibble = 0; nibble < 16; nibble++)
    {
        QTweak_Vec[nibble] = Tweak_Vec[Q[nibble]];
    }
    
    for (int nibble = 0; nibble < 16; nibble++)
    {
        TK[0][nibble] = (K0_Vec[nibble] ^ Tweak_Vec[nibble]);
        TK[1][nibble] = (K1_Vec[nibble] ^ Tweak_Vec[nibble]);
        TK[2][nibble] = (K0_Vec[nibble] ^ QTweak_Vec[nibble]);
        TK[3][nibble] = (K1_Vec[nibble] ^ QTweak_Vec[nibble]);
    }
}

void CRAFT_Encryption(int plaintext[4], int ciphertext[4], int TK[4][16])
{
    int RC3[32] = {0x1, 0x4, 0x2, 0x5, 0x6, 0x7, 0x3, 0x1, 0x4, 0x2, 0x5, 0x6, 0x7, 0x3, 0x1, 0x4, 0x2, 0x5, 0x6, 0x7, 0x3, 0x1, 0x4, 0x2, 0x5, 0x6, 0x7, 0x3, 0x1, 0x4, 0x2, 0x5};
    int RC4[32] = {0x1, 0x8, 0x4, 0x2, 0x9, 0xc, 0x6, 0xb, 0x5, 0xa, 0xd, 0xe, 0xf, 0x7, 0x3, 0x1, 0x8, 0x4, 0x2, 0x9, 0xc, 0x6, 0xb, 0x5, 0xa, 0xd, 0xe, 0xf, 0x7, 0x3, 0x1, 0x8};
    int P[16] = {0xf, 0xc, 0xd, 0xe, 0xa, 0x9, 0x8, 0xb, 0x6, 0x5, 0x4, 0x7, 0x1, 0x2, 0x3, 0x0};
    int plaintext_Vec[16];
    for (int group = 0; group < 4; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            plaintext_Vec[4 * group + nibble] = ((plaintext[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    
    for (int round = 0; round < TotalRound; round++)
    {
        int temp[16];
        for (int nibble = 0; nibble < 4; nibble++)
        {
            temp[nibble] = (plaintext_Vec[nibble] ^ plaintext_Vec[nibble + 8] ^ plaintext_Vec[nibble + 12]);
            temp[nibble + 4] = (plaintext_Vec[nibble + 4] ^ plaintext_Vec[nibble + 12]);
            temp[nibble + 8] = plaintext_Vec[nibble + 8];
            temp[nibble + 12] = plaintext_Vec[nibble + 12];
        }
        
        temp[4] ^= RC4[round];
        temp[5] ^= RC3[round];
        
        for (int nibble = 0; nibble < 16; nibble++)
        {
            temp[nibble] ^= TK[round%4][nibble];
        }
        
        if (round < 31)
        {
            for (int nibble = 0; nibble < 16; nibble++)
            {
                plaintext_Vec[nibble] = temp[P[nibble]];
            }
            
            for (int nibble = 0; nibble < 16; nibble++)
            {
                plaintext_Vec[nibble] = S[plaintext_Vec[nibble]];
            }
        }
        else
        {
            for (int nibble = 0; nibble < 16; nibble++)
            {
                plaintext_Vec[nibble] = temp[nibble];
            }
        }
    }
    
    for (int group = 0; group < 4; group++)
    {
        ciphertext[group] = 0;
        for (int nibble = 0; nibble < 4; nibble++)
        {
            ciphertext[group] ^= (plaintext_Vec[4 * group + nibble] << (4 * (3 - nibble)));
        }
    }
}

int main()
{
    srand(time(0));
    int K0_Difference[4] = {0x0007, 0x0000, 0x0007, 0x0000};
    int K1_Difference[4] = {0x0000, 0x0005, 0x0000, 0x0000};
    int Tweak_Difference[4] = {0x0000, 0x0000, 0x0000, 0x0000};
    int Plaintext_Difference[4] = {0x0000, 0x0000, 0x0007, 0x0000};
    int Ciphertext_Difference[4] = {0x0000, 0x0005, 0x0000, 0x0000};
    
    ofstream fout("MemoriseRightPair.out");
    
    clock_t start_time, end_time;
    start_time = clock();
    
    int K0_Pair1[4] = {0x6c6b, 0xd022, 0x4dc5, 0x65e3};
    int K1_Pair1[4] = {0x1d4d, 0x5753, 0xa30f, 0xa6d8};
    int Tweak_Pair1[4] = {0x08a2, 0x3a1b, 0x40f6, 0x376f};
    int K0_Pair2[4] = {0x6c6c, 0xd022, 0x4dc2, 0x65e3};
    int K1_Pair2[4] = {0x1d4d, 0x5756, 0xa30f, 0xa6d8};
    int Tweak_Pair2[4] = {0x08a2, 0x3a1b, 0x40f6, 0x376f};
    
    unsigned int RandomSeed[2];
    unsigned int TemporaryValue;
    int Random[8];
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            Random[j] = (rand()&(0xf));
        }
        RandomSeed[i] = ((Random[0] << 28) ^ (Random[1] << 24) ^ (Random[2] << 20) ^ (Random[3] << 16) ^ (Random[4] << 12) ^ (Random[5] << 8) ^ (Random[6] << 4) ^ (Random[7]));
    }
    
    int TK_Pair1[4][16];
    int TK_Pair2[4][16];
    
    InitialiseTK(K0_Pair1, K1_Pair1, Tweak_Pair1, TK_Pair1);
    InitialiseTK(K0_Pair2, K1_Pair2, Tweak_Pair2, TK_Pair2);
    
    int Counter = 0;
    
    for (int data1 = 0; data1 < (1 << 17); data1++)
    {
        for (int data2 = 0; data2 < (1 << 18); data2++)
        {
            int Plaintext_Pair1[4];
            int Ciphertext_Pair1[4];
            int Plaintext_Pair2[4];
            int Ciphertext_Pair2[4];
            
            for (int group = 0; group < 4; group++)
            {
                TemporaryValue = (RandomSeed[1] ^ (RandomSeed[1] << 31)^(RandomSeed[0] >> 1));
                RandomSeed[0] = RandomSeed[1];
                RandomSeed[1] = TemporaryValue;
                Plaintext_Pair1[group] = (RandomSeed[0] & (0xffff));
                Plaintext_Pair2[group] = (Plaintext_Pair1[group] ^ Plaintext_Difference[group]);
            }
            CRAFT_Encryption(Plaintext_Pair1, Ciphertext_Pair1, TK_Pair1);
            CRAFT_Encryption(Plaintext_Pair2, Ciphertext_Pair2, TK_Pair2);
            
            if (((Ciphertext_Pair1[0] ^ Ciphertext_Pair2[0]) == Ciphertext_Difference[0]) &&
                ((Ciphertext_Pair1[1] ^ Ciphertext_Pair2[1]) == Ciphertext_Difference[1]) &&
                ((Ciphertext_Pair1[2] ^ Ciphertext_Pair2[2]) == Ciphertext_Difference[2]) &&
                ((Ciphertext_Pair1[3] ^ Ciphertext_Pair2[3]) == Ciphertext_Difference[3]))
            {
                Counter += 1;
                
                cout<<"Right Pair "<<(dec)<<Counter<<endl;
                cout<<"Plaintext1: ";
                for (int group = 0; group < 4; group++)
                {
                    for (int nibble = 0; nibble < 4; nibble++)
                    {
                        cout<<(hex)<<((Plaintext_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
                        fout<<(hex)<<((Plaintext_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
                    }
                    cout<<" ";
                    fout<<" ";
                }
                cout<<endl;
                fout<<"\n";
                
                cout<<"Plaintext2: ";
                for (int group = 0; group < 4; group++)
                {
                    for (int nibble = 0; nibble < 4; nibble++)
                    {
                        cout<<(hex)<<((Plaintext_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
                        fout<<(hex)<<((Plaintext_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
                    }
                    cout<<" ";
                    fout<<" ";
                }
                cout<<endl;
                fout<<"\n";
                
                cout<<"Ciphertext1: ";
                for (int group = 0; group < 4; group++)
                {
                    for (int nibble = 0; nibble < 4; nibble++)
                    {
                        cout<<(hex)<<((Ciphertext_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
                        fout<<(hex)<<((Ciphertext_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
                    }
                    cout<<" ";
                    fout<<" ";
                }
                cout<<endl;
                fout<<"\n";
                
                cout<<"Ciphertext2: ";
                for (int group = 0; group < 4; group++)
                {
                    for (int nibble = 0; nibble < 4; nibble++)
                    {
                        cout<<(hex)<<((Ciphertext_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
                        fout<<(hex)<<((Ciphertext_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
                    }
                    cout<<" ";
                    fout<<" ";
                }
                cout<<endl;
                fout<<"\n";
            }
        }
    }
    
    cout<<"K0_Pair1: ";
    for (int group = 0; group < 4; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            cout<<(hex)<<((K0_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    cout<<endl;
    
    cout<<"K1_Pair1: ";
    for (int group = 0; group < 4; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            cout<<(hex)<<((K1_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    cout<<endl;
    
    cout<<"Tweak_Pair1: ";
    for (int group = 0; group < 4; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            cout<<(hex)<<((Tweak_Pair1[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    cout<<endl;
    
    cout<<"K0_Pair2: ";
    for (int group = 0; group < 4; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            cout<<(hex)<<((K0_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    cout<<endl;
    
    cout<<"K1_Pair2: ";
    for (int group = 0; group < 4; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            cout<<(hex)<<((K1_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    cout<<endl;
    
    cout<<"Tweak_Pair2: ";
    for (int group = 0; group < 4; group++)
    {
        for (int nibble = 0; nibble < 4; nibble++)
        {
            cout<<(hex)<<((Tweak_Pair2[group] >> (4 * (3 - nibble))) & (0xf));
        }
    }
    cout<<endl;
    
    cout<<"The number of right pairs: "<<(dec)<<Counter<<endl;
    end_time = clock();
    cout<<"Runtime: "<<(double)(end_time - start_time) / CLOCKS_PER_SEC<<"S"<<endl;
    
    fout.close();
    return 0;
}
